#include <iostream>
#include <vector>
#include <string>

class Otter
{
public:
    Otter(std::string controlSystem = "stepInput",
          float r = 0,
          float v_current = 0,
          float beta_current = 0,
          int tau_x = 120);

    void initialize_otter();

private:
    float nu[6];
    float u_actual[2];
    float u_control[2];
    float current_eta[6];
    int speed;
    std::string controlDescription;
    float C[6][6];
    float ref;
    float V_c;
    float beta_c;
    int tauX;
    std::string controlMode;
    std::string controls[2];
    std::string name;
    
    float T_n;
    float L;
    float B;
    float m;
    float mp;
    float m_total;
    float S_rg[3][3];
    float H_rg[6][6];
    float S_rp[3][3];
    
    float T_yaw; 
    float Umax;
    // Data for one pontoon
    float B_pont;
    float y_pont;
    float Cw_pont;
    float Cb_pont;
    
    // Inertia dyadic, volume displacement and draft
    
    float nabla;
    float T;
    float Ig_CG[3][3];
    float Ig[3][3];
    
    // Experimental propeller data including lever arms
    
    float l1;
    float l2;
    float k_pos;
    float k_neg;
    float n_max;
    float n_min;
    
    
    // MRB_CG = [ (m+mp)*I3 O3
    //		    O3   Ig]
    
   float MRB_CG[6][6];
   float MRB[6][6];
   
   // Hydrodynamic added mass
   
   float Xudot;
   float Yvdot;
   float Zwdot;
   float Kpdot;
   float Mqdot;
   float Nrdot; 
   float MA[6][6];
   float M[6][6];
   float Minv[6][6];
   
   
   
   // Hydrostatic quantities
   
   
   
   
   
   
   
   
   
   
    
    
    
    
    
     
    
};
